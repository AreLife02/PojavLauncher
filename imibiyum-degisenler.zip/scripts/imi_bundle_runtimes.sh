#!/usr/bin/env bash
# Imibiyum Launcher: downloads the arm64 Java runtimes (8, 17, 21, 25) that get bundled into the APK.
# Source: AngelAuraMC/angelauramc-openjdk-build (GPLv2 + Classpath Exception OpenJDK builds).
# Every file is checked against a pinned SHA-256, so the build fails loudly if the upstream file changes.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/app_pojavlauncher/src/main/assets/components/jre-raw"
BASE="https://github.com/AngelAuraMC/angelauramc-openjdk-build/releases/download"

mkdir -p "$OUT"

fetch() {
  local ver="$1" tag="$2" sha="$3"
  local file="$OUT/jre${ver}.tar.xz"
  if [ -f "$file" ] && echo "${sha}  ${file}" | sha256sum -c --status -; then
    echo "Java ${ver}: already downloaded"
  else
    echo "Java ${ver}: downloading"
    curl -fL --retry 4 --retry-delay 5 --connect-timeout 30 -o "$file" "${BASE}/${tag}/jre${ver}-android-arm64.tar.xz"
    echo "${sha}  ${file}" | sha256sum -c -
  fi
  # The app compares this marker to decide when a runtime has to be installed again
  echo "${sha}" | cut -c1-12 > "$OUT/jre${ver}.version"
}

fetch 8  download_jre8 9a59124d9791957d55c68be664ab76831f336cf2e1e1cd4414220c6fdbf0e06d
fetch 17 download      e162c860fe05ee4a4e4af7606437419879f6c748386a7b09fa77d10db6a64091
fetch 21 download      8d41ec401ee59f7722df60ed991f81ad146e130452804bfdd8a05d3436f7bbfe
fetch 25 download      d3eb7afe2240c26728a1bb440502c5f18ac3883e932d202dd7f0c9bcbbce4c37

echo "Bundled runtimes ready in $OUT"
