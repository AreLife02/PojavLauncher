package net.kdt.pojavlaunch.fragments;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.LruCache;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import net.kdt.pojavlaunch.PojavApplication;
import net.kdt.pojavlaunch.R;
import net.kdt.pojavlaunch.Tools;
import net.kdt.pojavlaunch.modloaders.ImiMods;
import net.kdt.pojavlaunch.utils.DownloadUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Full screen mod manager: installed mods (on/off/delete) and Modrinth discovery. */
public class ImiModsFragment extends Fragment {
    public static final String TAG = "ImiModsFragment";
    private static final String ARG_VERSION = "game_version";
    private static final String ARG_DIR = "mods_dir";

    private static final String[][] CATEGORIES = {
            {"Hepsi", ""}, {"Optimizasyon", "optimization"}, {"Araçlar", "utility"},
            {"Dekorasyon", "decoration"}, {"Macera", "adventure"}, {"Oyun mekaniği", "game-mechanics"},
            {"Ekipman", "equipment"}, {"Depolama", "storage"}, {"Kütüphane", "library"}
    };

    private static final LruCache<String, Bitmap> ICONS = new LruCache<>(80);

    public static void start(FragmentActivity activity, String gameVersion, File modsDir) {
        Bundle b = new Bundle();
        b.putString(ARG_VERSION, gameVersion);
        b.putString(ARG_DIR, modsDir.getAbsolutePath());
        Tools.swapFragment(activity, ImiModsFragment.class, TAG, b);
    }

    private String mGameVersion;
    private File mModsDir;
    private boolean mDiscover;
    private String mCategory = "";
    private int mSearchToken;

    private TextView mTabInstalled, mTabDiscover, mStatus;
    private View mDiscoverBar;
    private EditText mSearch;
    private LinearLayout mChips;
    private ListView mList;

    private final List<File> mInstalled = new ArrayList<>();
    private final List<ImiMods.Hit> mHits = new ArrayList<>();
    private final Set<String> mInstalledSlugs = new HashSet<>();
    private final Set<String> mBusy = new HashSet<>();

    public ImiModsFragment() {
        super(R.layout.fragment_imi_mods);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Bundle args = getArguments();
        mGameVersion = args == null ? "" : args.getString(ARG_VERSION, "");
        mModsDir = new File(args == null ? "" : args.getString(ARG_DIR, ""));

        mTabInstalled = view.findViewById(R.id.imi_mods_tab_installed);
        mTabDiscover = view.findViewById(R.id.imi_mods_tab_discover);
        mStatus = view.findViewById(R.id.imi_mods_status);
        mDiscoverBar = view.findViewById(R.id.imi_mods_discover_bar);
        mSearch = view.findViewById(R.id.imi_mods_search);
        mChips = view.findViewById(R.id.imi_mods_chips);
        mList = view.findViewById(R.id.imi_mods_list);
        ((TextView) view.findViewById(R.id.imi_mods_sub)).setText(getString(R.string.imi_mods_for, mGameVersion));

        mTabInstalled.setOnClickListener(v -> setMode(false));
        mTabDiscover.setOnClickListener(v -> setMode(true));
        mSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                search();
                return true;
            }
            return false;
        });

        for (String[] cat : CATEGORIES) {
            TextView chip = new TextView(requireContext());
            chip.setTag(cat[1]);
            chip.setText(cat[0]);
            chip.setTextSize(12);
            int h = getResources().getDimensionPixelSize(R.dimen._10sdp);
            int pv = getResources().getDimensionPixelSize(R.dimen._6sdp);
            chip.setPadding(h, pv, h, pv);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd(getResources().getDimensionPixelSize(R.dimen._6sdp));
            chip.setOnClickListener(x -> {
                mCategory = cat[1];
                styleChips();
                search();
            });
            mChips.addView(chip, lp);
        }
        styleChips();

        mList.setAdapter(mAdapter);
        setMode(false);
    }

    private void styleTab(TextView tab, boolean on) {
        tab.setBackgroundResource(on ? R.drawable.imi_button_play : R.drawable.imi_field_bg);
        tab.setTextColor(getResources().getColor(on ? R.color.imi_button_text : R.color.primary_text));
    }

    private void styleChips() {
        for (int i = 0; i < mChips.getChildCount(); i++) {
            TextView chip = (TextView) mChips.getChildAt(i);
            boolean on = chip.getTag().equals(mCategory);
            chip.setBackgroundResource(on ? R.drawable.imi_button_play : R.drawable.imi_field_bg);
            chip.setTextColor(getResources().getColor(on ? R.color.imi_button_text : R.color.primary_text));
        }
    }

    private void setMode(boolean discover) {
        mDiscover = discover;
        styleTab(mTabInstalled, !discover);
        styleTab(mTabDiscover, discover);
        mDiscoverBar.setVisibility(discover ? View.VISIBLE : View.GONE);
        mStatus.setText("");
        refreshInstalled();
        if (discover && mHits.isEmpty()) search();
        mAdapter.notifyDataSetChanged();
        if (!discover && mInstalled.isEmpty()) mStatus.setText(R.string.imi_mods_empty);
    }

    private void refreshInstalled() {
        mInstalled.clear();
        mInstalledSlugs.clear();
        File[] files = mModsDir.listFiles();
        if (files == null) return;
        Arrays.sort(files, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        for (File f : files) {
            String n = f.getName();
            if (n.endsWith(".jar") || n.endsWith(".jar.disabled")) mInstalled.add(f);
            else if (n.startsWith(".imi_")) mInstalledSlugs.add(n.substring(5));
        }
    }

    private void search() {
        final String q = mSearch.getText().toString().trim();
        final String cat = mCategory.isEmpty() ? null : mCategory;
        final int token = ++mSearchToken;
        mStatus.setText(R.string.imi_mod_searching);
        PojavApplication.sExecutorService.execute(() -> {
            try {
                final List<ImiMods.Hit> result = ImiMods.search(q, mGameVersion, cat);
                post(() -> {
                    if (token != mSearchToken) return;
                    mHits.clear();
                    mHits.addAll(result);
                    mStatus.setText(result.isEmpty() ? getString(R.string.imi_mod_none) : "");
                    mAdapter.notifyDataSetChanged();
                });
            } catch (Exception e) {
                post(() -> {
                    if (token == mSearchToken) mStatus.setText(R.string.imi_mod_error);
                });
            }
        });
    }

    private void post(Runnable r) {
        if (getActivity() != null) getActivity().runOnUiThread(r);
    }

    private static String shortNumber(long n) {
        if (n >= 1_000_000) return String.format(Locale.US, "%.1fM", n / 1_000_000f);
        if (n >= 1_000) return String.format(Locale.US, "%.1fK", n / 1_000f);
        return String.valueOf(n);
    }

    private void loadIcon(final ImageView view, final String url) {
        view.setTag(url);
        view.setImageDrawable(null);
        if (url == null) return;
        Bitmap cached = ICONS.get(url);
        if (cached != null) {
            view.setImageBitmap(cached);
            return;
        }
        PojavApplication.sExecutorService.execute(() -> {
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                DownloadUtils.download(url, out);
                byte[] data = out.toByteArray();
                Bitmap bmp = BitmapFactory.decodeByteArray(data, 0, data.length);
                if (bmp == null) return;
                ICONS.put(url, bmp);
                post(() -> {
                    if (url.equals(view.getTag())) view.setImageBitmap(bmp);
                });
            } catch (Exception ignored) { }
        });
    }

    private void install(final ImiMods.Hit hit) {
        if (!mBusy.add(hit.slug)) return;
        mAdapter.notifyDataSetChanged();
        mStatus.setText(getString(R.string.imi_mod_installing, hit.title));
        PojavApplication.sExecutorService.execute(() -> {
            final String name = ImiMods.installMod(mModsDir, hit.slug, mGameVersion);
            post(() -> {
                mBusy.remove(hit.slug);
                mStatus.setText(name == null
                        ? getString(R.string.imi_mod_failed, hit.title)
                        : getString(R.string.imi_mod_done, hit.title));
                refreshInstalled();
                mAdapter.notifyDataSetChanged();
            });
        });
    }

    private final BaseAdapter mAdapter = new BaseAdapter() {
        @Override public int getCount() { return mDiscover ? mHits.size() : mInstalled.size(); }
        @Override public Object getItem(int position) { return mDiscover ? mHits.get(position) : mInstalled.get(position); }
        @Override public long getItemId(int position) { return position; }
        @Override public int getViewTypeCount() { return 2; }
        @Override public int getItemViewType(int position) { return mDiscover ? 1 : 0; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            return mDiscover ? onlineView(position, convertView, parent) : installedView(position, convertView, parent);
        }
    };

    private View onlineView(int position, View convertView, ViewGroup parent) {
        View v = convertView != null ? convertView
                : LayoutInflater.from(parent.getContext()).inflate(R.layout.item_imi_mod_online, parent, false);
        final ImiMods.Hit hit = mHits.get(position);
        ((TextView) v.findViewById(R.id.imi_mod_name)).setText(hit.title);
        ((TextView) v.findViewById(R.id.imi_mod_meta)).setText(
                hit.author + " · " + getString(R.string.imi_mods_downloads, shortNumber(hit.downloads)));
        ((TextView) v.findViewById(R.id.imi_mod_desc)).setText(hit.description);
        loadIcon((ImageView) v.findViewById(R.id.imi_mod_icon), hit.iconUrl);

        TextView action = v.findViewById(R.id.imi_mod_action);
        boolean installed = mInstalledSlugs.contains(hit.slug);
        boolean busy = mBusy.contains(hit.slug);
        action.setText(busy ? "…" : getString(installed ? R.string.imi_mods_installed_mark : R.string.imi_mods_install));
        action.setAlpha(installed || busy ? 0.6f : 1f);
        action.setOnClickListener(x -> {
            if (!installed) install(hit);
        });
        return v;
    }

    private View installedView(int position, View convertView, ViewGroup parent) {
        View v = convertView != null ? convertView
                : LayoutInflater.from(parent.getContext()).inflate(R.layout.item_imi_mod_installed, parent, false);
        final File file = mInstalled.get(position);
        final boolean enabled = file.getName().endsWith(".jar");
        String name = file.getName().replace(".jar.disabled", "").replace(".jar", "");

        ((TextView) v.findViewById(R.id.imi_inst_name)).setText(name);
        SwitchCompat sw = v.findViewById(R.id.imi_inst_switch);
        sw.setOnCheckedChangeListener(null);
        sw.setChecked(enabled);
        sw.setOnCheckedChangeListener((b, checked) -> {
            File target = new File(file.getParentFile(), checked
                    ? file.getName().replace(".jar.disabled", ".jar")
                    : file.getName() + ".disabled");
            if (file.renameTo(target)) {
                refreshInstalled();
                mAdapter.notifyDataSetChanged();
            }
        });
        v.findViewById(R.id.imi_inst_delete).setOnClickListener(x ->
                new AlertDialog.Builder(requireContext())
                        .setMessage(getString(R.string.imi_mods_delete_ask, name))
                        .setPositiveButton(R.string.imi_mods_yes, (d, w) -> {
                            file.delete();
                            refreshInstalled();
                            mAdapter.notifyDataSetChanged();
                            if (mInstalled.isEmpty()) mStatus.setText(R.string.imi_mods_empty);
                        })
                        .setNegativeButton(R.string.imi_mods_no, null)
                        .show());
        return v;
    }
}
