package net.kdt.pojavlaunch.prefs.screens;

import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;

import androidx.preference.ListPreference;
import androidx.preference.SwitchPreference;
import androidx.preference.SwitchPreferenceCompat;

import net.kdt.pojavlaunch.R;
import net.kdt.pojavlaunch.Tools;
import net.kdt.pojavlaunch.prefs.CustomSeekBarPreference;
import net.kdt.pojavlaunch.prefs.LauncherPreferences;

/**
 * Fragment for any settings video related
 */
public class LauncherPreferenceVideoFragment extends LauncherPreferenceFragment {
    @Override
    public void onCreatePreferences(Bundle b, String str) {
        addPreferencesFromResource(R.xml.pref_video);
        int resolution = (int) (LauncherPreferences.PREF_SCALE_FACTOR * 100);

        //Disable notch checking behavior on android 8.1 and below.
        requirePreference("ignoreNotch").setVisible(Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && LauncherPreferences.PREF_NOTCH_SIZE > 0);

        CustomSeekBarPreference resolutionSeekbar = requirePreference("resolutionRatio",
                CustomSeekBarPreference.class);
        resolutionSeekbar.setSuffix(" %");

        // #724 bug fix
        if (resolution < 25) {
            resolutionSeekbar.setValue(100);
        } else {
            resolutionSeekbar.setValue(resolution);
        }

        // Sustained performance is only available since Nougat
        SwitchPreference sustainedPerfSwitch = requirePreference("sustainedPerformance",
                SwitchPreference.class);
        sustainedPerfSwitch.setVisible(Build.VERSION.SDK_INT >= Build.VERSION_CODES.N);
        sustainedPerfSwitch.setChecked(LauncherPreferences.PREF_SUSTAINED_PERFORMANCE);

        requirePreference("alternate_surface", SwitchPreferenceCompat.class).setChecked(LauncherPreferences.PREF_USE_ALTERNATE_SURFACE);
        requirePreference("force_vsync", SwitchPreferenceCompat.class).setChecked(LauncherPreferences.PREF_FORCE_VSYNC);

        ListPreference rendererListPreference = requirePreference("renderer",
                ListPreference.class);
        Tools.RenderersList renderersList = Tools.getCompatibleRenderers(getContext());
        rendererListPreference.setEntries(renderersList.rendererDisplayNames);
        rendererListPreference.setEntryValues(renderersList.rendererIds.toArray(new String[0]));

        requirePreference("imi_perf_preset", ListPreference.class).setOnPreferenceChangeListener((pref, value) -> {
            applyPreset(String.valueOf(value));
            return true;
        });

        computeVisibility();
    }

    private void setList(String key, String value) {
        requirePreference(key, ListPreference.class).setValue(value);
    }

    /** Preset: fps, render distance, graphics, particles, shadows, clouds, resolution %, sustained perf */
    private void applyPreset(String preset) {
        String[] v;
        switch (preset) {
            case "battery":  v = new String[]{"30", "6", "0", "2", "false", "false", "70", "true"}; break;
            case "balanced": v = new String[]{"60", "8", "0", "1", "false", "false", "100", "false"}; break;
            case "fps":      v = new String[]{"120", "6", "0", "2", "false", "false", "80", "false"}; break;
            case "quality":  v = new String[]{"60", "12", "1", "0", "true", "true", "100", "false"}; break;
            default: return;
        }
        setList("imi_opt_fps", v[0]);
        setList("imi_opt_render", v[1]);
        setList("imi_opt_graphics", v[2]);
        setList("imi_opt_particles", v[3]);
        setList("imi_opt_shadows", v[4]);
        setList("imi_opt_clouds", v[5]);
        requirePreference("resolutionRatio", CustomSeekBarPreference.class).setValue(Integer.parseInt(v[6]));
        requirePreference("sustainedPerformance", SwitchPreference.class).setChecked(Boolean.parseBoolean(v[7]));
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences p, String s) {
        super.onSharedPreferenceChanged(p, s);
        computeVisibility();
    }

    private void computeVisibility(){
        requirePreference("force_vsync", SwitchPreferenceCompat.class)
                .setVisible(LauncherPreferences.PREF_USE_ALTERNATE_SURFACE);
    }
}
