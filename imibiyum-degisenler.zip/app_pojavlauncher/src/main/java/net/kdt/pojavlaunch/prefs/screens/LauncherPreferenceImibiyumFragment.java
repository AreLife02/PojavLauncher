package net.kdt.pojavlaunch.prefs.screens;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

import androidx.preference.Preference;

import net.kdt.pojavlaunch.R;
import net.kdt.pojavlaunch.prefs.LauncherPreferences;

import java.io.File;

/** İmibiyum's own settings screen. */
public class LauncherPreferenceImibiyumFragment extends LauncherPreferenceFragment {
    private static final String RELEASES = "https://github.com/AreLife02/PojavLauncher/releases/tag/son-surum";

    @Override
    public void onCreatePreferences(Bundle b, String str) {
        addPreferencesFromResource(R.xml.pref_imibiyum);

        int ram = LauncherPreferences.PREF_RAM_ALLOCATION;
        requirePreference("imi_ram_tip").setSummary(getString(R.string.imi_pref_ram_desc, ram));

        requirePreference("imi_clear_cache").setOnPreferenceClickListener(p -> {
            try {
                File dir = requireContext().getCacheDir();
                deleteContents(dir);
                Toast.makeText(requireContext(), R.string.imi_pref_cache_done, Toast.LENGTH_SHORT).show();
            } catch (Exception ignored) {}
            return true;
        });
        requirePreference("imi_update").setOnPreferenceClickListener(p -> open(RELEASES));
        requirePreference("imi_discord").setOnPreferenceClickListener(p -> open("https://discord.gg/imibiyum"));
    }

    private boolean open(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception ignored) {}
        return true;
    }

    private static void deleteContents(File dir) {
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isDirectory()) deleteContents(f);
            f.delete();
        }
    }
}
