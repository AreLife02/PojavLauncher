package net.kdt.pojavlaunch.views;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Draws a Minecraft skin as a small 3D character that can be rotated by dragging.
 * Orthographic projection: every face of the character ends up as a parallelogram,
 * so each face is drawn with a plain affine matrix (no OpenGL needed).
 */
public class SkinView3D extends View {
    private static final class Part {
        final float cx, cy, cz, hw, hh, hd; // centre and half sizes (already inflated)
        final int u, v, w, h, d;             // texture origin and box size in texels
        final int layer;
        Part(float cx, float cy, float cz, int w, int h, int d, float inflate, int u, int v, int layer) {
            this.cx = cx; this.cy = cy; this.cz = cz;
            this.hw = w / 2f + inflate; this.hh = h / 2f + inflate; this.hd = d / 2f + inflate;
            this.u = u; this.v = v; this.w = w; this.h = h; this.d = d;
            this.layer = layer;
        }
    }

    private static final class Face {
        float[] dst = new float[6];
        Rect src;
        float depth;
    }

    private final List<Part> mParts = new ArrayList<>();
    private final List<Face> mFaces = new ArrayList<>();
    private final Paint mPaint = new Paint();
    private final Matrix mMatrix = new Matrix();
    private final float[] mSrcPts = new float[6];
    private Bitmap mSkin;
    private float mFactor = 1f;
    private float mYaw = 28f;
    private float mPitch = 10f;
    private boolean mTouching;
    private float mLastX, mLastY;

    public SkinView3D(Context context) { super(context); init(); }
    public SkinView3D(Context context, AttributeSet attrs) { super(context, attrs); init(); }
    public SkinView3D(Context context, AttributeSet attrs, int defStyleAttr) { super(context, attrs, defStyleAttr); init(); }

    private void init() {
        mPaint.setFilterBitmap(false);
        mPaint.setAntiAlias(false);
        setBackgroundColor(Color.TRANSPARENT);
    }

    /** Sets the skin to show. Accepts the old 64x32 layout as well as 64x64. */
    public void setSkin(Bitmap skin, boolean slim) {
        if (skin == null) {
            mSkin = null;
            invalidate();
            return;
        }
        mSkin = normalize(skin);
        mFactor = mSkin.getWidth() / 64f;
        buildParts(slim);
        invalidate();
    }

    /** Guesses if a skin uses the slim (3px arms) model by looking at unused arm pixels. */
    public static boolean detectSlim(Bitmap skin) {
        if (skin == null || skin.getHeight() < skin.getWidth()) return false;
        float f = skin.getWidth() / 64f;
        int[] ys = {22, 26, 30};
        for (int y : ys) {
            int px = skin.getPixel((int) (54 * f), (int) (y * f));
            if (Color.alpha(px) != 0) return false;
        }
        return true;
    }

    private static Bitmap normalize(Bitmap src) {
        int w = src.getWidth(), h = src.getHeight();
        if (h >= w) return src;
        Bitmap out = Bitmap.createBitmap(w, w, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.drawBitmap(src, 0, 0, null);
        float f = w / 64f;
        copyFlipped(src, c, (int) (0 * f), (int) (16 * f), (int) (16 * f), (int) (16 * f), (int) (16 * f), (int) (48 * f));
        copyFlipped(src, c, (int) (40 * f), (int) (16 * f), (int) (16 * f), (int) (16 * f), (int) (32 * f), (int) (48 * f));
        return out;
    }

    private static void copyFlipped(Bitmap src, Canvas c, int sx, int sy, int w, int h, int dx, int dy) {
        if (sx + w > src.getWidth() || sy + h > src.getHeight()) return;
        Matrix m = new Matrix();
        m.preScale(-1, 1);
        Bitmap part = Bitmap.createBitmap(src, sx, sy, w, h, m, false);
        c.drawBitmap(part, dx, dy, null);
    }

    private void buildParts(boolean slim) {
        mParts.clear();
        int armW = slim ? 3 : 4;
        // y is relative to the middle of the figure (32 units tall)
        mParts.add(new Part(0, 12, 0, 8, 8, 8, 0f, 0, 0, 0));          // head
        mParts.add(new Part(0, 12, 0, 8, 8, 8, 0.5f, 32, 0, 1));       // hat
        mParts.add(new Part(0, 2, 0, 8, 12, 4, 0f, 16, 16, 0));        // body
        mParts.add(new Part(0, 2, 0, 8, 12, 4, 0.25f, 16, 32, 1));     // jacket
        float armX = 4 + armW / 2f;
        mParts.add(new Part(-armX, 2, 0, armW, 12, 4, 0f, 40, 16, 0));      // right arm
        mParts.add(new Part(-armX, 2, 0, armW, 12, 4, 0.25f, 40, 32, 1));   // right sleeve
        mParts.add(new Part(armX, 2, 0, armW, 12, 4, 0f, 32, 48, 0));       // left arm
        mParts.add(new Part(armX, 2, 0, armW, 12, 4, 0.25f, 48, 48, 1));    // left sleeve
        mParts.add(new Part(-2, -10, 0, 4, 12, 4, 0f, 0, 16, 0));      // right leg
        mParts.add(new Part(-2, -10, 0, 4, 12, 4, 0.25f, 0, 32, 1));   // right pants
        mParts.add(new Part(2, -10, 0, 4, 12, 4, 0f, 16, 48, 0));      // left leg
        mParts.add(new Part(2, -10, 0, 4, 12, 4, 0.25f, 0, 48, 1));    // left pants
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        postInvalidateOnAnimation();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                mTouching = true;
                mLastX = e.getX();
                mLastY = e.getY();
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                return true;
            case MotionEvent.ACTION_MOVE:
                mYaw += (e.getX() - mLastX) * 0.8f;
                mPitch -= (e.getY() - mLastY) * 0.4f;
                if (mPitch > 40f) mPitch = 40f;
                if (mPitch < -40f) mPitch = -40f;
                mLastX = e.getX();
                mLastY = e.getY();
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                mTouching = false;
                invalidate();
                return true;
            default:
                return true;
        }
    }

    // face order: 0 front, 1 back, 2 right(-x), 3 left(+x), 4 top, 5 bottom
    private static final float[][] NORMALS = {
            {0, 0, 1}, {0, 0, -1}, {-1, 0, 0}, {1, 0, 0}, {0, 1, 0}, {0, -1, 0}
    };

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Bitmap skin = mSkin;
        if (skin == null) return;
        if (!mTouching) mYaw += 0.7f;

        float ya = (float) Math.toRadians(mYaw), pa = (float) Math.toRadians(mPitch);
        float cy = (float) Math.cos(ya), sy = (float) Math.sin(ya);
        float cp = (float) Math.cos(pa), sp = (float) Math.sin(pa);
        float scale = Math.min(getHeight() / 35f, getWidth() / 21f);
        float ox = getWidth() / 2f, oy = getHeight() / 2f;

        mFaces.clear();
        for (Part p : mParts) {
            for (int f = 0; f < 6; f++) {
                float[] n = NORMALS[f];
                float nx = n[0] * cy + n[2] * sy;
                float nz0 = -n[0] * sy + n[2] * cy;
                float nz = n[1] * sp + nz0 * cp;
                if (nz <= 0.0001f) continue; // facing away

                float[] tl = new float[3], tr = new float[3], bl = new float[3];
                corners(p, f, tl, tr, bl);
                Face face = new Face();
                project(tl, face.dst, 0, cy, sy, cp, sp, scale, ox, oy);
                project(tr, face.dst, 2, cy, sy, cp, sp, scale, ox, oy);
                project(bl, face.dst, 4, cy, sy, cp, sp, scale, ox, oy);
                float[] cen = {p.cx, p.cy, p.cz};
                face.depth = depthOf(cen, cy, sy, cp, sp) + p.layer * 0.01f + (f == 4 || f == 5 ? 0 : 0);
                face.src = srcRect(p, f);
                mFaces.add(face);
            }
        }
        Collections.sort(mFaces, new Comparator<Face>() {
            @Override public int compare(Face a, Face b) { return Float.compare(a.depth, b.depth); }
        });

        for (Face face : mFaces) {
            int w = face.src.width(), h = face.src.height();
            if (w <= 0 || h <= 0) continue;
            mSrcPts[0] = 0; mSrcPts[1] = 0;
            mSrcPts[2] = w; mSrcPts[3] = 0;
            mSrcPts[4] = 0; mSrcPts[5] = h;
            mMatrix.setPolyToPoly(mSrcPts, 0, face.dst, 0, 3);
            canvas.save();
            canvas.concat(mMatrix);
            canvas.drawBitmap(skin, face.src, new Rect(0, 0, w, h), mPaint);
            canvas.restore();
        }

        if (!mTouching) postInvalidateOnAnimation();
    }

    private static float depthOf(float[] c, float cy, float sy, float cp, float sp) {
        float z1 = -c[0] * sy + c[2] * cy;
        return c[1] * sp + z1 * cp;
    }

    private static void project(float[] p, float[] out, int idx, float cy, float sy, float cp, float sp,
                                float scale, float ox, float oy) {
        float x1 = p[0] * cy + p[2] * sy;
        float z1 = -p[0] * sy + p[2] * cy;
        float y2 = p[1] * cp - z1 * sp;
        out[idx] = ox + x1 * scale;
        out[idx + 1] = oy - y2 * scale;
    }

    private void corners(Part p, int face, float[] tl, float[] tr, float[] bl) {
        float x0 = p.cx, y0 = p.cy, z0 = p.cz;
        float hw = p.hw, hh = p.hh, hd = p.hd;
        switch (face) {
            case 0: // front (+z)
                set(tl, x0 - hw, y0 + hh, z0 + hd); set(tr, x0 + hw, y0 + hh, z0 + hd); set(bl, x0 - hw, y0 - hh, z0 + hd); break;
            case 1: // back (-z)
                set(tl, x0 + hw, y0 + hh, z0 - hd); set(tr, x0 - hw, y0 + hh, z0 - hd); set(bl, x0 + hw, y0 - hh, z0 - hd); break;
            case 2: // right side of the character (-x)
                set(tl, x0 - hw, y0 + hh, z0 - hd); set(tr, x0 - hw, y0 + hh, z0 + hd); set(bl, x0 - hw, y0 - hh, z0 - hd); break;
            case 3: // left side of the character (+x)
                set(tl, x0 + hw, y0 + hh, z0 + hd); set(tr, x0 + hw, y0 + hh, z0 - hd); set(bl, x0 + hw, y0 - hh, z0 + hd); break;
            case 4: // top
                set(tl, x0 - hw, y0 + hh, z0 - hd); set(tr, x0 + hw, y0 + hh, z0 - hd); set(bl, x0 - hw, y0 + hh, z0 + hd); break;
            default: // bottom
                set(tl, x0 - hw, y0 - hh, z0 + hd); set(tr, x0 + hw, y0 - hh, z0 + hd); set(bl, x0 - hw, y0 - hh, z0 - hd); break;
        }
    }

    private static void set(float[] a, float x, float y, float z) {
        a[0] = x; a[1] = y; a[2] = z;
    }

    private Rect srcRect(Part p, int face) {
        int u = p.u, v = p.v, w = p.w, h = p.h, d = p.d;
        int x, y, rw, rh;
        switch (face) {
            case 0: x = u + d; y = v + d; rw = w; rh = h; break;           // front
            case 1: x = u + 2 * d + w; y = v + d; rw = w; rh = h; break;   // back
            case 2: x = u; y = v + d; rw = d; rh = h; break;               // right
            case 3: x = u + d + w; y = v + d; rw = d; rh = h; break;       // left
            case 4: x = u + d; y = v; rw = w; rh = d; break;               // top
            default: x = u + d + w; y = v; rw = w; rh = d; break;          // bottom
        }
        return new Rect(Math.round(x * mFactor), Math.round(y * mFactor),
                Math.round((x + rw) * mFactor), Math.round((y + rh) * mFactor));
    }
}
