package net.kdt.pojavlaunch.profiles;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import net.kdt.pojavlaunch.R;
import net.kdt.pojavlaunch.Tools;
import net.kdt.pojavlaunch.modloaders.ImiMods;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** "Mod ekle": search Modrinth for Fabric mods of the profile's version and install them. */
public class ModAddDialog {
    public static void open(Context context, String gameVersion, File modsDir) {
        View root = LayoutInflater.from(context).inflate(R.layout.dialog_imi_mods, null);
        EditText search = root.findViewById(R.id.imi_mod_search);
        TextView status = root.findViewById(R.id.imi_mod_status);
        ListView listView = root.findViewById(R.id.imi_mod_list);

        List<ImiMods.Hit> hits = new ArrayList<>();
        ArrayAdapter<ImiMods.Hit> adapter = new ArrayAdapter<>(context, R.layout.item_imi_mod, hits);
        listView.setAdapter(adapter);

        Runnable doSearch = () -> {
            String q = search.getText().toString().trim();
            status.setText(R.string.imi_mod_searching);
            new Thread(() -> {
                try {
                    List<ImiMods.Hit> result = ImiMods.search(q, gameVersion);
                    Tools.runOnUiThread(() -> {
                        hits.clear();
                        hits.addAll(result);
                        adapter.notifyDataSetChanged();
                        status.setText(result.isEmpty() ? context.getString(R.string.imi_mod_none) : "");
                    });
                } catch (Exception e) {
                    Tools.runOnUiThread(() -> status.setText(R.string.imi_mod_error));
                }
            }).start();
        };
        search.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                doSearch.run();
                return true;
            }
            return false;
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            ImiMods.Hit hit = hits.get(position);
            status.setText(context.getString(R.string.imi_mod_installing, hit.title));
            new Thread(() -> {
                String name = ImiMods.installMod(modsDir, hit.slug, gameVersion);
                Tools.runOnUiThread(() -> status.setText(name == null
                        ? context.getString(R.string.imi_mod_failed, hit.title)
                        : context.getString(R.string.imi_mod_done, hit.title)));
            }).start();
        });

        AlertDialog dialog = new AlertDialog.Builder(context).setView(root).create();
        if (dialog.getWindow() != null)
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();
        doSearch.run();
    }
}
