package net.kdt.pojavlaunch.modloaders;

import net.kdt.pojavlaunch.Tools;
import net.kdt.pojavlaunch.utils.DownloadUtils;
import net.kdt.pojavlaunch.utils.FileUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/** Imibiyum helpers: automatic Fabric + FPS mods and Modrinth mod search/install. */
public class ImiMods {
    private static final String API = "https://api.modrinth.com/v2";

    /** Modrinth slugs of the FPS mods installed automatically. */
    public static final String[] FPS_MODS = {
            "fabric-api", "lithium", "ferrite-core", "modernfix", "entityculling"
    };

    public static class Hit {
        public String slug, title, description;
        @Override public String toString() { return title + (description == null || description.isEmpty() ? "" : "\n" + description); }
    }

    /** Returns the Minecraft version for a plain release or a Fabric version id, otherwise null. */
    public static String baseGameVersion(String id) {
        if (id == null) return null;
        if (id.matches("\\d+\\.\\d+(\\.\\d+)?")) return id;
        if (id.startsWith("fabric-loader-")) {
            String v = id.substring(id.lastIndexOf('-') + 1);
            if (v.matches("\\d+\\.\\d+(\\.\\d+)?")) return v;
        }
        return null;
    }

    public static boolean isFabric(String id) {
        return id != null && id.startsWith("fabric-loader-");
    }

    /** Makes sure the Fabric version json exists for the game version and returns its id (null on failure). */
    public static String ensureFabric(String gameVersion) {
        try {
            FabricVersion[] loaders = FabriclikeUtils.FABRIC_UTILS.downloadLoaderVersions(gameVersion);
            if (loaders == null || loaders.length == 0) return null;
            String loader = loaders[0].version;
            for (FabricVersion v : loaders) {
                if (v.stable) { loader = v.version; break; }
            }
            String id = "fabric-loader-" + loader + "-" + gameVersion;
            File dir = new File(Tools.DIR_HOME_VERSION, id);
            File json = new File(dir, id + ".json");
            if (!json.exists()) {
                String body = DownloadUtils.downloadString(
                        FabriclikeUtils.FABRIC_UTILS.createJsonDownloadUrl(gameVersion, loader));
                String realId = new JSONObject(body).getString("id");
                dir = new File(Tools.DIR_HOME_VERSION, realId);
                FileUtils.ensureDirectory(dir);
                Tools.write(new File(dir, realId + ".json").getAbsolutePath(), body);
                return realId;
            }
            return id;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /** Installs the FPS mod set into modsDir. Failures of single mods are ignored. */
    public static void installFps(File modsDir, String gameVersion, boolean sodium) {
        for (String slug : FPS_MODS) installMod(modsDir, slug, gameVersion);
        if (sodium) {
            installMod(modsDir, "sodium", gameVersion);
        }
    }

    /** Installs (or updates) a mod; returns the file name or null when unavailable. */
    public static String installMod(File modsDir, String slug, String gameVersion) {
        try {
            FileUtils.ensureDirectory(modsDir);
            File marker = new File(modsDir, ".imi_" + slug);
            String old = marker.exists() ? Tools.read(marker.getAbsolutePath()).trim() : null;
            if (old != null) {
                String[] parts = old.split("\\|", 2);
                if (parts.length == 2) {
                    File oldFile = new File(modsDir, parts[1]);
                    if (parts[0].equals(gameVersion) && oldFile.exists()) return parts[1];
                    oldFile.delete();
                }
            }
            String url = API + "/project/" + URLEncoder.encode(slug, "UTF-8")
                    + "/version?loaders=" + URLEncoder.encode("[\"fabric\"]", "UTF-8")
                    + "&game_versions=" + URLEncoder.encode("[\"" + gameVersion + "\"]", "UTF-8");
            JSONArray versions = new JSONArray(DownloadUtils.downloadString(url));
            if (versions.length() == 0) return null;
            JSONArray files = versions.getJSONObject(0).getJSONArray("files");
            if (files.length() == 0) return null;
            JSONObject file = files.getJSONObject(0);
            for (int i = 0; i < files.length(); i++) {
                if (files.getJSONObject(i).optBoolean("primary")) { file = files.getJSONObject(i); break; }
            }
            String name = file.getString("filename");
            File out = new File(modsDir, name);
            File tmp = new File(modsDir, name + ".part");
            DownloadUtils.downloadFile(file.getString("url"), tmp);
            if (out.exists()) out.delete();
            if (!tmp.renameTo(out)) return null;
            Tools.write(marker.getAbsolutePath(), gameVersion + "|" + name);
            return name;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static List<Hit> search(String query, String gameVersion) throws IOException {
        List<Hit> hits = new ArrayList<>();
        try {
            String facets = "[[\"project_type:mod\"],[\"categories:fabric\"],[\"versions:" + gameVersion + "\"]]";
            String url = API + "/search?limit=25&index=downloads&query=" + URLEncoder.encode(query, "UTF-8")
                    + "&facets=" + URLEncoder.encode(facets, "UTF-8");
            JSONArray arr = new JSONObject(DownloadUtils.downloadString(url)).getJSONArray("hits");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Hit h = new Hit();
                h.slug = o.getString("slug");
                h.title = o.getString("title");
                h.description = o.optString("description", "");
                hits.add(h);
            }
        } catch (org.json.JSONException e) {
            throw new IOException(e);
        }
        return hits;
    }
}
