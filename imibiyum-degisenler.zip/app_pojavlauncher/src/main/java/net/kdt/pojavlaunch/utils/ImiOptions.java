package net.kdt.pojavlaunch.utils;

import net.kdt.pojavlaunch.prefs.LauncherPreferences;

import java.io.File;
import java.io.IOException;
import net.kdt.pojavlaunch.Tools;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;

/** Writes the in-game options chosen in the launcher settings into the game's options.txt. */
public class ImiOptions {
    /** launcher preference key -> options.txt key */
    private static final String[][] MAP = {
            {"imi_opt_fps", "maxFps"},
            {"imi_opt_render", "renderDistance"},
            {"imi_opt_graphics", "graphicsMode"},
            {"imi_opt_particles", "particles"},
            {"imi_opt_shadows", "entityShadows"},
            {"imi_opt_clouds", "renderClouds"},
            {"imi_opt_gui", "guiScale"},
    };

    public static void apply(File gameDir) {
        try {
            List<String[]> changes = new ArrayList<>();
            for (String[] m : MAP) {
                String value = LauncherPreferences.DEFAULT_PREF.getString(m[0], "");
                if (value == null || value.isEmpty()) continue;
                if (m[1].equals("renderClouds")) value = "\"" + value + "\"";
                changes.add(new String[]{m[1], value});
            }
            if (changes.isEmpty()) return;

            gameDir.mkdirs();
            File file = new File(gameDir, "options.txt");
            List<String> lines = new ArrayList<>();
            if (file.exists()) lines.addAll(Arrays.asList(Tools.read(file.getAbsolutePath()).split("\\r?\\n")));

            for (String[] change : changes) {
                String prefix = change[0] + ":";
                boolean found = false;
                for (int i = 0; i < lines.size(); i++) {
                    if (lines.get(i).startsWith(prefix)) {
                        lines.set(i, prefix + change[1]);
                        found = true;
                        break;
                    }
                }
                if (!found) lines.add(prefix + change[1]);
            }
            StringBuilder sb = new StringBuilder();
            for (String line : lines) if (!line.isEmpty()) sb.append(line).append('\n');
            Tools.write(file.getAbsolutePath(), sb.toString());
        } catch (IOException | RuntimeException ignored) {
        }
    }
}
