package net.kdt.pojavlaunch.fragments;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import net.kdt.pojavlaunch.PojavApplication;
import net.kdt.pojavlaunch.PojavProfile;
import net.kdt.pojavlaunch.R;
import net.kdt.pojavlaunch.value.MinecraftAccount;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.Pattern;

/**
 * Looks up the skin of any player by name (public Mojang services), shows a preview
 * and applies it to the signed in Microsoft account.
 */
public class SkinFragment extends Fragment {
    public static final String TAG = "SkinFragment";
    private static final Pattern NAME_PATTERN = Pattern.compile("[A-Za-z0-9_]{3,16}");

    private EditText mNameInput;
    private TextView mStatus;
    private ImageView mPreview;
    private Button mApplyButton;

    private String mSkinUrl;
    private boolean mSlim;

    public SkinFragment() {
        super(R.layout.fragment_skin);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        mNameInput = view.findViewById(R.id.skin_name_input);
        mStatus = view.findViewById(R.id.skin_status);
        mPreview = view.findViewById(R.id.skin_preview);
        mApplyButton = view.findViewById(R.id.skin_apply_button);
        Button searchButton = view.findViewById(R.id.skin_search_button);

        MinecraftAccount account = PojavProfile.getCurrentProfileContent(requireContext(), null);
        if (account != null && account.username != null) mNameInput.setText(account.username);

        searchButton.setOnClickListener(v -> search());
        mNameInput.setOnEditorActionListener((v, actionId, event) -> {
            search();
            return true;
        });
        mApplyButton.setOnClickListener(v -> apply());
    }

    private void search() {
        final String name = mNameInput.getText().toString().trim();
        if (!NAME_PATTERN.matcher(name).matches()) {
            mStatus.setText(R.string.imi_skin_not_found);
            return;
        }
        mStatus.setText(R.string.imi_skin_searching);
        mApplyButton.setEnabled(false);
        mSkinUrl = null;
        PojavApplication.sExecutorService.execute(() -> {
            try {
                String profile = httpGet("https://api.mojang.com/users/profiles/minecraft/" + name);
                if (profile == null) {
                    post(() -> mStatus.setText(R.string.imi_skin_not_found));
                    return;
                }
                JSONObject profileJson = new JSONObject(profile);
                String id = profileJson.getString("id");
                String foundName = profileJson.optString("name", name);

                String session = httpGet("https://sessionserver.mojang.com/session/minecraft/profile/" + id);
                if (session == null) {
                    post(() -> mStatus.setText(R.string.imi_skin_not_found));
                    return;
                }
                JSONArray props = new JSONObject(session).getJSONArray("properties");
                String textures = null;
                for (int i = 0; i < props.length(); i++) {
                    JSONObject prop = props.getJSONObject(i);
                    if ("textures".equals(prop.optString("name"))) textures = prop.getString("value");
                }
                if (textures == null) {
                    post(() -> mStatus.setText(R.string.imi_skin_not_found));
                    return;
                }
                JSONObject skin = new JSONObject(new String(Base64.decode(textures, Base64.DEFAULT), StandardCharsets.UTF_8))
                        .getJSONObject("textures").optJSONObject("SKIN");
                if (skin == null) {
                    post(() -> mStatus.setText(R.string.imi_skin_not_found));
                    return;
                }
                final String url = skin.getString("url");
                final boolean slim = skin.optJSONObject("metadata") != null
                        && "slim".equals(skin.getJSONObject("metadata").optString("model"));

                Bitmap skinBitmap;
                HttpURLConnection conn = open(url);
                try (InputStream in = conn.getInputStream()) {
                    skinBitmap = BitmapFactory.decodeStream(in);
                } finally {
                    conn.disconnect();
                }
                if (skinBitmap == null) throw new IllegalStateException("skin decode failed");
                final Bitmap figure = renderFigure(skinBitmap, slim);

                post(() -> {
                    mSkinUrl = url;
                    mSlim = slim;
                    mPreview.setImageBitmap(figure);
                    mStatus.setText(getString(R.string.imi_skin_found, foundName));
                    mApplyButton.setEnabled(true);
                });
            } catch (Exception e) {
                post(() -> mStatus.setText(R.string.imi_skin_error));
            }
        });
    }

    private void apply() {
        final String url = mSkinUrl;
        if (url == null) return;
        MinecraftAccount account = PojavProfile.getCurrentProfileContent(requireContext(), null);
        if (account == null || !account.isMicrosoft) {
            mStatus.setText(R.string.imi_skin_offline);
            return;
        }
        final String token = account.accessToken;
        final boolean slim = mSlim;
        mApplyButton.setEnabled(false);
        PojavApplication.sExecutorService.execute(() -> {
            try {
                HttpURLConnection conn = open("https://api.minecraftservices.com/minecraft/profile/skins");
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("Authorization", "Bearer " + token);
                conn.setRequestProperty("Content-Type", "application/json");
                JSONObject body = new JSONObject();
                body.put("variant", slim ? "slim" : "classic");
                body.put("url", url);
                try (OutputStream out = conn.getOutputStream()) {
                    out.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }
                final int code = conn.getResponseCode();
                conn.disconnect();
                post(() -> {
                    mApplyButton.setEnabled(true);
                    if (code >= 200 && code < 300) mStatus.setText(R.string.imi_skin_applied);
                    else if (code == 401) mStatus.setText(R.string.imi_skin_expired);
                    else mStatus.setText(getString(R.string.imi_skin_failed, code));
                });
            } catch (Exception e) {
                post(() -> {
                    mApplyButton.setEnabled(true);
                    mStatus.setText(R.string.imi_skin_error);
                });
            }
        });
    }

    private void post(Runnable r) {
        if (getActivity() != null) getActivity().runOnUiThread(r);
    }

    private static HttpURLConnection open(String url) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        conn.setRequestProperty("User-Agent", "ImibiyumLauncher");
        return conn;
    }

    /** Returns the body, or null when the service answers "not found". */
    private static String httpGet(String url) throws Exception {
        HttpURLConnection conn = open(url);
        try {
            int code = conn.getResponseCode();
            if (code == 204 || code == 404) return null;
            if (code != 200) throw new IllegalStateException("HTTP " + code);
            try (InputStream in = conn.getInputStream()) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                return out.toString("UTF-8");
            }
        } finally {
            conn.disconnect();
        }
    }

    /** Draws a small front view of the skin (16x32) and scales it up without smoothing. */
    private static Bitmap renderFigure(Bitmap skin, boolean slim) {
        boolean modern = skin.getHeight() >= 64;
        int armW = slim ? 3 : 4;
        Bitmap fig = Bitmap.createBitmap(16, 32, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(fig);
        Paint p = new Paint();
        p.setFilterBitmap(false);

        draw(c, p, skin, 8, 8, 8, 8, 4, 0, false);            // head
        draw(c, p, skin, 40, 8, 8, 8, 4, 0, false);           // hat layer
        draw(c, p, skin, 20, 20, 8, 12, 4, 8, false);         // body
        draw(c, p, skin, 44, 20, armW, 12, 4 - armW, 8, false); // right arm
        if (modern) draw(c, p, skin, 36, 52, armW, 12, 12, 8, false);
        else draw(c, p, skin, 44, 20, armW, 12, 12, 8, true);
        draw(c, p, skin, 4, 20, 4, 12, 4, 20, false);         // right leg
        if (modern) draw(c, p, skin, 20, 52, 4, 12, 8, 20, false);
        else draw(c, p, skin, 4, 20, 4, 12, 8, 20, true);

        return Bitmap.createScaledBitmap(fig, 128, 256, false);
    }

    private static void draw(Canvas c, Paint p, Bitmap skin, int sx, int sy, int w, int h, int dx, int dy, boolean mirror) {
        Bitmap part = Bitmap.createBitmap(skin, sx, sy, w, h);
        if (mirror) {
            Matrix m = new Matrix();
            m.preScale(-1, 1);
            part = Bitmap.createBitmap(part, 0, 0, w, h, m, false);
        }
        c.drawBitmap(part, null, new Rect(dx, dy, dx + w, dy + h), p);
    }
}
