package net.kdt.pojavlaunch.fragments;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Base64;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import net.kdt.pojavlaunch.PojavApplication;
import net.kdt.pojavlaunch.PojavProfile;
import net.kdt.pojavlaunch.R;
import net.kdt.pojavlaunch.value.MinecraftAccount;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;
import java.util.Random;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Looks up the skin of any player by name (public Mojang services), shows a preview
 * and applies it to the signed in Microsoft account.
 */
public class SkinFragment extends Fragment {
    public static final String TAG = "SkinFragment";
    private static final Pattern NAME_PATTERN = Pattern.compile("[A-Za-z0-9_]{3,16}");

    private EditText mNameInput;
    private TextView mStatus;
    private ImageView mPreview;
    private Button mApplyButton;

    private String mSkinUrl;
    private boolean mSlim;

    public SkinFragment() {
        super(R.layout.fragment_skin);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        mNameInput = view.findViewById(R.id.skin_name_input);
        mStatus = view.findViewById(R.id.skin_status);
        mPreview = view.findViewById(R.id.skin_preview);
        mApplyButton = view.findViewById(R.id.skin_apply_button);
        Button searchButton = view.findViewById(R.id.skin_search_button);

        MinecraftAccount account = PojavProfile.getCurrentProfileContent(requireContext(), null);
        if (account != null && account.username != null) mNameInput.setText(account.username);

        searchButton.setOnClickListener(v -> search());
        mNameInput.setOnEditorActionListener((v, actionId, event) -> {
            search();
            return true;
        });
        mApplyButton.setOnClickListener(v -> apply());
        setupGallery(view);
    }

    private static class SkinData {
        String name;
        String url;
        boolean slim;
        Bitmap figure;
    }

    /** Looks a player up and downloads the skin. Null when the player or skin does not exist. */
    private static SkinData fetchSkin(String name) throws Exception {
        String profile = lookupProfile(name);
        if (profile == null) return null;
        JSONObject profileJson = new JSONObject(profile);
        String id = profileJson.getString("id");

        String session = httpGet("https://sessionserver.mojang.com/session/minecraft/profile/" + id);
        if (session == null) return null;
        JSONArray props = new JSONObject(session).getJSONArray("properties");
        String textures = null;
        for (int i = 0; i < props.length(); i++) {
            JSONObject prop = props.getJSONObject(i);
            if ("textures".equals(prop.optString("name"))) textures = prop.getString("value");
        }
        if (textures == null) return null;
        JSONObject skin = new JSONObject(new String(Base64.decode(textures, Base64.DEFAULT), StandardCharsets.UTF_8))
                .getJSONObject("textures").optJSONObject("SKIN");
        if (skin == null) return null;

        SkinData data = new SkinData();
        data.name = profileJson.optString("name", name);
        data.url = toHttps(skin.getString("url"));
        data.slim = skin.optJSONObject("metadata") != null
                && "slim".equals(skin.getJSONObject("metadata").optString("model"));

        Bitmap skinBitmap;
        HttpURLConnection conn = open(data.url);
        try (InputStream in = conn.getInputStream()) {
            skinBitmap = BitmapFactory.decodeStream(in);
        } finally {
            conn.disconnect();
        }
        if (skinBitmap == null) throw new IllegalStateException("skin decode failed");
        data.figure = renderFigure(skinBitmap, data.slim);
        return data;
    }

    private void show(SkinData d) {
        mSkinBytes = null;
        mSkinUrl = d.url;
        mSlim = d.slim;
        mPreview.setImageBitmap(d.figure);
        mStatus.setText(getString(R.string.imi_skin_found, d.name));
        mApplyButton.setEnabled(true);
    }

    private void search() {
        refreshGallery();
        final String name = mNameInput.getText().toString().trim();
        if (!NAME_PATTERN.matcher(name).matches()) {
            mStatus.setText(R.string.imi_skin_not_found);
            return;
        }
        mStatus.setText(R.string.imi_skin_searching);
        mApplyButton.setEnabled(false);
        mSkinUrl = null;
        PojavApplication.sExecutorService.execute(() -> {
            try {
                final SkinData d = fetchSkin(name);
                if (d == null) post(() -> mStatus.setText(R.string.imi_skin_not_found));
                else post(() -> show(d));
            } catch (Exception e) {
                final String detail = describe(e);
                post(() -> mStatus.setText(getString(R.string.imi_skin_error_detail, detail)));
            }
        });
    }

    // ---- Ready-made skins gallery (bundled in the APK, assets/skins) ----------------------------

    private static final String[] CATEGORIES = {
            "tümü", "kız", "erkek", "savaşçı", "ninja", "robot", "yaratık", "komik", "oyun", "imibiyum"
    };
    private static final int GALLERY_PAGE = 9;

    private static class CatSkin {
        String name;
        String file;
        List<String> tags = new ArrayList<>();
        boolean slim;
        byte[] png;
        Bitmap figure;
    }

    private final List<CatSkin> mCatalog = new ArrayList<>();
    private final Random mRandom = new Random();
    private String mCategory = "tümü";
    private byte[] mSkinBytes;
    private LinearLayout mChips;
    private LinearLayout mGalleryRow;
    private LinearLayout mGallery;
    private int mGalleryCount;

    private void setupGallery(View view) {
        mGallery = view.findViewById(R.id.skin_gallery);
        mChips = view.findViewById(R.id.skin_chips);
        view.findViewById(R.id.skin_refresh_button).setOnClickListener(v -> refreshGallery());
        loadCatalog();
        for (String key : CATEGORIES) {
            TextView chip = new TextView(requireContext());
            chip.setTag(key);
            chip.setText(key.substring(0, 1).toUpperCase(new Locale("tr")) + key.substring(1));
            chip.setTextSize(12);
            int h = getResources().getDimensionPixelSize(R.dimen._10sdp);
            int v = getResources().getDimensionPixelSize(R.dimen._6sdp);
            chip.setPadding(h, v, h, v);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd(getResources().getDimensionPixelSize(R.dimen._6sdp));
            chip.setOnClickListener(x -> {
                mCategory = key;
                styleChips();
                refreshGallery();
            });
            mChips.addView(chip, lp);
        }
        styleChips();
        refreshGallery();
    }

    private void styleChips() {
        for (int i = 0; i < mChips.getChildCount(); i++) {
            TextView chip = (TextView) mChips.getChildAt(i);
            boolean on = chip.getTag().equals(mCategory);
            chip.setBackgroundResource(on ? R.drawable.imi_button_play : R.drawable.imi_field_bg);
            chip.setTextColor(getResources().getColor(on ? R.color.imi_button_text : R.color.primary_text));
        }
    }

    private void loadCatalog() {
        try (InputStream in = requireContext().getAssets().open("skins/catalog.json")) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            JSONArray arr = new JSONObject(out.toString("UTF-8")).getJSONArray("skins");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                CatSkin c = new CatSkin();
                c.name = o.getString("n");
                c.file = o.getString("f");
                c.slim = o.optBoolean("slim");
                JSONArray tags = o.optJSONArray("t");
                if (tags != null) for (int t = 0; t < tags.length(); t++) c.tags.add(tags.getString(t));
                mCatalog.add(c);
            }
        } catch (Exception ignored) { }
    }

    private boolean matches(CatSkin c, String q) {
        if (c.name.toLowerCase(new Locale("tr")).contains(q)) return true;
        for (String t : c.tags) if (t.contains(q)) return true;
        return false;
    }

    /** Shows a fresh random selection for the current category (also used by the refresh button). */
    private void refreshGallery() {
        if (mGallery == null) return;
        mGallery.removeAllViews();
        mGalleryRow = null;
        mGalleryCount = 0;

        List<CatSkin> pool = new ArrayList<>();
        for (CatSkin c : mCatalog) {
            if (mCategory.equals("tümü") || c.tags.contains(mCategory)) pool.add(c);
        }
        String q = mNameInput.getText().toString().trim().toLowerCase(new Locale("tr"));
        if (!q.isEmpty()) {
            List<CatSkin> hits = new ArrayList<>();
            for (CatSkin c : pool) if (matches(c, q)) hits.add(c);
            if (!hits.isEmpty()) pool = hits;
        }
        Collections.shuffle(pool, mRandom);
        for (int i = 0; i < pool.size() && i < GALLERY_PAGE; i++) addTile(pool.get(i));
    }

    private void ensureLoaded(CatSkin c) {
        if (c.figure != null) return;
        try (InputStream in = requireContext().getAssets().open("skins/" + c.file)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            c.png = out.toByteArray();
            Bitmap skin = BitmapFactory.decodeByteArray(c.png, 0, c.png.length);
            c.figure = renderFigure(skin, c.slim);
        } catch (Exception ignored) { }
    }

    private void select(CatSkin c) {
        ensureLoaded(c);
        if (c.figure == null) return;
        mSkinBytes = c.png;
        mSkinUrl = null;
        mSlim = c.slim;
        mPreview.setImageBitmap(c.figure);
        mStatus.setText(getString(R.string.imi_skin_selected, c.name));
        mApplyButton.setEnabled(true);
    }

    private void addTile(CatSkin c) {
        if (!isAdded() || mGallery == null) return;
        ensureLoaded(c);
        if (c.figure == null) return;
        if (mGalleryRow == null || mGalleryCount % 3 == 0) {
            mGalleryRow = new LinearLayout(requireContext());
            mGalleryRow.setOrientation(LinearLayout.HORIZONTAL);
            mGallery.addView(mGalleryRow, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        mGalleryCount++;
        int gap = getResources().getDimensionPixelSize(R.dimen._4sdp);

        LinearLayout tile = new LinearLayout(requireContext());
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER_HORIZONTAL);
        tile.setBackgroundResource(R.drawable.imi_card_bg);
        tile.setPadding(gap, gap * 2, gap, gap * 2);

        ImageView img = new ImageView(requireContext());
        img.setImageBitmap(c.figure);
        img.setAdjustViewBounds(true);
        tile.addView(img, new LinearLayout.LayoutParams(
                getResources().getDimensionPixelSize(R.dimen._40sdp),
                getResources().getDimensionPixelSize(R.dimen._80sdp)));

        TextView label = new TextView(requireContext());
        label.setText(c.name);
        label.setTextColor(getResources().getColor(R.color.primary_text));
        label.setTextSize(11);
        label.setSingleLine(true);
        label.setGravity(Gravity.CENTER);
        tile.addView(label, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        tile.setOnClickListener(v -> select(c));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(gap, gap, gap, gap);
        mGalleryRow.addView(tile, lp);
    }

    private void apply() {
        final String url = mSkinUrl;
        final byte[] bytes = mSkinBytes;
        if (url == null && bytes == null) return;
        MinecraftAccount account = PojavProfile.getCurrentProfileContent(requireContext(), null);
        if (account == null || !account.isMicrosoft) {
            mStatus.setText(R.string.imi_skin_offline);
            return;
        }
        final String token = account.accessToken;
        final boolean slim = mSlim;
        mApplyButton.setEnabled(false);
        PojavApplication.sExecutorService.execute(() -> {
            try {
                HttpURLConnection conn = open("https://api.minecraftservices.com/minecraft/profile/skins");
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("Authorization", "Bearer " + token);
                if (bytes != null) {
                    // Upload the PNG itself (multipart/form-data)
                    String boundary = "----imibiyum" + System.currentTimeMillis();
                    conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
                    try (OutputStream out = conn.getOutputStream()) {
                        String head = "--" + boundary + "\r\nContent-Disposition: form-data; name=\"variant\"\r\n\r\n"
                                + (slim ? "slim" : "classic") + "\r\n"
                                + "--" + boundary + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"skin.png\"\r\n"
                                + "Content-Type: image/png\r\n\r\n";
                        out.write(head.getBytes(StandardCharsets.UTF_8));
                        out.write(bytes);
                        out.write(("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
                    }
                } else {
                    conn.setRequestProperty("Content-Type", "application/json");
                    JSONObject body = new JSONObject();
                    body.put("variant", slim ? "slim" : "classic");
                    body.put("url", url);
                    try (OutputStream out = conn.getOutputStream()) {
                        out.write(body.toString().getBytes(StandardCharsets.UTF_8));
                    }
                }
                final int code = conn.getResponseCode();
                conn.disconnect();
                post(() -> {
                    mApplyButton.setEnabled(true);
                    if (code >= 200 && code < 300) mStatus.setText(R.string.imi_skin_applied);
                    else if (code == 401) mStatus.setText(R.string.imi_skin_expired);
                    else mStatus.setText(getString(R.string.imi_skin_failed, code));
                });
            } catch (Exception e) {
                final String detail = describe(e);
                post(() -> {
                    mApplyButton.setEnabled(true);
                    mStatus.setText(getString(R.string.imi_skin_error_detail, detail));
                });
            }
        });
    }

    /** Official name lookup first, the older endpoint as a fallback. Null when the player does not exist. */
    private static String lookupProfile(String name) throws Exception {
        try {
            return httpGet("https://api.minecraftservices.com/minecraft/profile/lookup/name/" + name);
        } catch (Exception first) {
            return httpGet("https://api.mojang.com/users/profiles/minecraft/" + name);
        }
    }

    /** The texture server hands out http:// links, but Android blocks plain http traffic. */
    private static String toHttps(String url) {
        return url.startsWith("http://") ? "https://" + url.substring("http://".length()) : url;
    }

    private static String describe(Exception e) {
        String message = e.getMessage();
        String text = e.getClass().getSimpleName() + (message == null ? "" : ": " + message);
        return text.length() > 140 ? text.substring(0, 140) : text;
    }

    private void post(Runnable r) {
        if (getActivity() != null) getActivity().runOnUiThread(r);
    }

    private static HttpURLConnection open(String url) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        conn.setRequestProperty("User-Agent", "ImibiyumLauncher");
        return conn;
    }

    /** Returns the body, or null when the service answers "not found". */
    private static String httpGet(String url) throws Exception {
        HttpURLConnection conn = open(url);
        try {
            int code = conn.getResponseCode();
            if (code == 204 || code == 404) return null;
            if (code != 200) throw new IllegalStateException("HTTP " + code);
            try (InputStream in = conn.getInputStream()) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                return out.toString("UTF-8");
            }
        } finally {
            conn.disconnect();
        }
    }

    /** Draws a small front view of the skin (16x32) and scales it up without smoothing. */
    private static Bitmap renderFigure(Bitmap skin, boolean slim) {
        boolean modern = skin.getHeight() >= 64;
        int armW = slim ? 3 : 4;
        Bitmap fig = Bitmap.createBitmap(16, 32, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(fig);
        Paint p = new Paint();
        p.setFilterBitmap(false);

        draw(c, p, skin, 8, 8, 8, 8, 4, 0, false);            // head
        draw(c, p, skin, 40, 8, 8, 8, 4, 0, false);           // hat layer
        draw(c, p, skin, 20, 20, 8, 12, 4, 8, false);         // body
        draw(c, p, skin, 44, 20, armW, 12, 4 - armW, 8, false); // right arm
        if (modern) draw(c, p, skin, 36, 52, armW, 12, 12, 8, false);
        else draw(c, p, skin, 44, 20, armW, 12, 12, 8, true);
        draw(c, p, skin, 4, 20, 4, 12, 4, 20, false);         // right leg
        if (modern) draw(c, p, skin, 20, 52, 4, 12, 8, 20, false);
        else draw(c, p, skin, 4, 20, 4, 12, 8, 20, true);

        return Bitmap.createScaledBitmap(fig, 128, 256, false);
    }

    private static void draw(Canvas c, Paint p, Bitmap skin, int sx, int sy, int w, int h, int dx, int dy, boolean mirror) {
        Bitmap part = Bitmap.createBitmap(skin, sx, sy, w, h);
        if (mirror) {
            Matrix m = new Matrix();
            m.preScale(-1, 1);
            part = Bitmap.createBitmap(part, 0, 0, w, h, m, false);
        }
        c.drawBitmap(part, null, new Rect(dx, dy, dx + w, dy + h), p);
    }
}
