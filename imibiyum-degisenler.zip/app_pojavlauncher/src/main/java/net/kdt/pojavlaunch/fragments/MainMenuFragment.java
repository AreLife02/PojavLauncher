package net.kdt.pojavlaunch.fragments;

import static net.kdt.pojavlaunch.Tools.openPath;
import static net.kdt.pojavlaunch.Tools.shareLog;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.kdt.mcgui.mcVersionSpinner;

import net.kdt.pojavlaunch.CustomControlsActivity;
import net.kdt.pojavlaunch.R;
import net.kdt.pojavlaunch.Tools;
import net.kdt.pojavlaunch.extra.ExtraConstants;
import net.kdt.pojavlaunch.extra.ExtraCore;
import net.kdt.pojavlaunch.prefs.LauncherPreferences;
import net.kdt.pojavlaunch.progresskeeper.ProgressKeeper;
import net.kdt.pojavlaunch.value.launcherprofiles.LauncherProfiles;
import net.kdt.pojavlaunch.value.launcherprofiles.MinecraftProfile;

import java.io.File;

public class MainMenuFragment extends Fragment {
    public static final String TAG = "MainMenuFragment";

    private mcVersionSpinner mVersionSpinner;

    public MainMenuFragment(){
        super(R.layout.fragment_launcher);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        View mSkinButton = view.findViewById(R.id.skin_button);
        View mDiscordButton = view.findViewById(R.id.discord_button);
        View mCustomControlButton = view.findViewById(R.id.custom_control_button);
        View mInstallJarButton = view.findViewById(R.id.install_jar_button);
        View mShareLogsButton = view.findViewById(R.id.share_logs_button);
        View mOpenDirectoryButton = view.findViewById(R.id.open_files_button);

        bindAction(mSkinButton, R.drawable.imi_card_skin, R.drawable.ic_imi_skin, R.string.imi_menu_skin, R.string.imi_menu_skin_desc);
        bindAction(mDiscordButton, R.drawable.imi_card_discord, R.drawable.ic_discord, R.string.imi_menu_discord, R.string.imi_menu_discord_desc);
        bindAction(mCustomControlButton, R.drawable.imi_card_controls, R.drawable.ic_menu_custom_controls, R.string.imi_menu_controls, R.string.imi_menu_controls_desc);
        bindAction(mInstallJarButton, R.drawable.imi_card_mods, R.drawable.ic_menu_install_jar, R.string.imi_menu_jar, R.string.imi_menu_jar_desc);
        bindAction(mShareLogsButton, R.drawable.imi_card_report, android.R.drawable.ic_menu_share, R.string.imi_menu_logs, R.string.imi_menu_logs_desc);
        bindAction(mOpenDirectoryButton, R.drawable.imi_card_folder, R.drawable.ic_folder, R.string.imi_menu_folder, R.string.imi_menu_folder_desc);

        ImageButton mEditProfileButton = view.findViewById(R.id.edit_profile_button);
        Button mPlayButton = view.findViewById(R.id.play_button);
        mVersionSpinner = view.findViewById(R.id.mc_version_spinner);

        bindWorld(view.findViewById(R.id.world_skyblock), R.drawable.imibiyum_card_skyblock, R.string.imi_world_skyblock_tag, "Skyblock", R.string.imi_world_skyblock_desc);
        bindWorld(view.findViewById(R.id.world_survival), R.drawable.imibiyum_card_survival, R.string.imi_world_survival_tag, "Survival", R.string.imi_world_survival_desc);
        bindWorld(view.findViewById(R.id.world_elytrabox), R.drawable.imibiyum_card_elytrabox, R.string.imi_world_elytrabox_tag, "Elytrabox", R.string.imi_world_elytrabox_desc);

        mSkinButton.setOnClickListener(v -> Tools.swapFragment(requireActivity(), SkinFragment.class, SkinFragment.TAG, null));
        mDiscordButton.setOnClickListener(v -> Tools.openURL(requireActivity(), getString(R.string.discord_invite)));
        mCustomControlButton.setOnClickListener(v -> startActivity(new Intent(requireContext(), CustomControlsActivity.class)));
        mInstallJarButton.setOnClickListener(v -> runInstallerWithConfirmation(false));
        mInstallJarButton.setOnLongClickListener(v->{
            runInstallerWithConfirmation(true);
            return true;
        });
        mEditProfileButton.setOnClickListener(v -> mVersionSpinner.openProfileEditor(requireActivity()));

        mPlayButton.setOnClickListener(v -> ExtraCore.setValue(ExtraConstants.LAUNCH_GAME, true));

        mShareLogsButton.setOnClickListener((v) -> shareLog(requireContext()));

        mOpenDirectoryButton.setOnClickListener((v)-> {
            Tools.switchDemo(Tools.isDemoProfile(v.getContext())); // avoid switching accounts being able to access
            if(Tools.isDemoProfile(v.getContext())){
                Toast.makeText(v.getContext(), R.string.toast_not_available_demo, Toast.LENGTH_LONG).show();
                return;
            }

            openPath(v.getContext(), getCurrentProfileDirectory(), false);
        });


        mCustomControlButton.setOnLongClickListener((v)->{
            Tools.swapFragment(requireActivity(), GamepadMapperFragment.class, GamepadMapperFragment.TAG, null);
            return true;
        });
    }

    private void bindAction(View card, int image, int icon, int label, int desc) {
        ((ImageView) card.findViewById(R.id.action_image)).setImageResource(image);
        ((ImageView) card.findViewById(R.id.action_icon)).setImageResource(icon);
        ((TextView) card.findViewById(R.id.action_label)).setText(label);
        ((TextView) card.findViewById(R.id.action_desc)).setText(desc);
    }

    private void bindWorld(View card, int image, int tag, String title, int desc) {
        ((ImageView) card.findViewById(R.id.world_image)).setImageResource(image);
        ((TextView) card.findViewById(R.id.world_tag)).setText(tag);
        ((TextView) card.findViewById(R.id.world_title)).setText(title);
        ((TextView) card.findViewById(R.id.world_desc)).setText(desc);
    }

    private File getCurrentProfileDirectory() {
        String currentProfile = LauncherPreferences.DEFAULT_PREF.getString(LauncherPreferences.PREF_KEY_CURRENT_PROFILE, null);
        if(!Tools.isValidString(currentProfile)) return new File(Tools.DIR_GAME_NEW);
        LauncherProfiles.load();
        MinecraftProfile profileObject = LauncherProfiles.mainProfileJson.profiles.get(currentProfile);
        if(profileObject == null) return new File(Tools.DIR_GAME_NEW);
        return Tools.getGameDirPath(profileObject);
    }

    @Override
    public void onResume() {
        super.onResume();
        mVersionSpinner.reloadProfiles();
    }

    private void runInstallerWithConfirmation(boolean isCustomArgs) {
        // avoid using custom installers to install a version
        if(Tools.isLocalProfile(requireContext()) || Tools.isDemoProfile(requireContext())){
            Toast.makeText(requireContext(), R.string.toast_not_available_demo, Toast.LENGTH_LONG).show();
            return;
        }

        if (ProgressKeeper.getTaskCount() == 0)
            Tools.installMod(requireActivity(), isCustomArgs);
        else
            Toast.makeText(requireContext(), R.string.tasks_ongoing, Toast.LENGTH_LONG).show();
    }
}
