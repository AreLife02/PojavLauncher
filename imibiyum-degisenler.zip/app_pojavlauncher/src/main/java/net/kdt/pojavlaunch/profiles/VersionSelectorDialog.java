package net.kdt.pojavlaunch.profiles;

import static net.kdt.pojavlaunch.extra.ExtraCore.getValue;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import net.kdt.pojavlaunch.JMinecraftVersionList;
import net.kdt.pojavlaunch.R;
import net.kdt.pojavlaunch.Tools;
import net.kdt.pojavlaunch.extra.ExtraConstants;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Imibiyum version picker: a flat, searchable list of the supported release versions.
 * Test / old versions are hidden behind a toggle.
 */
public class VersionSelectorDialog {
    /** The server supports 1.20.4 and above */
    private static final int[] MIN_VERSION = {1, 20, 4};

    private static class Entry {
        final String id;
        final boolean snapshot;
        final boolean installed;
        Entry(String id, boolean snapshot, boolean installed) {
            this.id = id;
            this.snapshot = snapshot;
            this.installed = installed;
        }
    }

    public static void open(Context context, boolean hideCustomVersions, VersionSelectorListener listener) {
        View root = LayoutInflater.from(context).inflate(R.layout.dialog_imi_versions, null);
        EditText search = root.findViewById(R.id.imi_ver_search);
        ListView listView = root.findViewById(R.id.imi_ver_list);
        TextView toggle = root.findViewById(R.id.imi_ver_all_toggle);

        JMinecraftVersionList list = (JMinecraftVersionList) getValue(ExtraConstants.RELEASE_TABLE);
        JMinecraftVersionList.Version[] versions = (list == null || list.versions == null)
                ? new JMinecraftVersionList.Version[0] : list.versions;

        List<Entry> main = new ArrayList<>();
        List<Entry> all = new ArrayList<>();

        if (!hideCustomVersions) {
            String[] installed = new File(Tools.DIR_GAME_NEW + "/versions").list();
            if (installed != null) {
                Arrays.sort(installed);
                for (String id : installed) {
                    main.add(new Entry(id, false, true));
                    all.add(new Entry(id, false, true));
                }
            }
        }
        for (JMinecraftVersionList.Version v : versions) {
            if (v.id == null || v.type == null) continue;
            boolean snapshot = v.type.equals("snapshot");
            all.add(new Entry(v.id, snapshot, false));
            if (v.type.equals("release") && isSupported(v.id)) main.add(new Entry(v.id, false, false));
        }

        final boolean[] showAll = {false};
        final List<Entry> shown = new ArrayList<>();
        final Context ctx = context;

        BaseAdapter adapter = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int i) { return shown.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View convertView, ViewGroup parent) {
                TextView tv = (TextView) (convertView != null ? convertView
                        : LayoutInflater.from(ctx).inflate(R.layout.item_imi_version, parent, false));
                Entry e = shown.get(i);
                tv.setText(e.installed ? e.id + "  ·  " + ctx.getString(R.string.imi_ver_installed) : e.id);
                return tv;
            }
        };
        listView.setAdapter(adapter);

        Runnable refresh = () -> {
            String q = search.getText().toString().trim().toLowerCase(Locale.ROOT);
            shown.clear();
            for (Entry e : (showAll[0] ? all : main)) {
                if (q.isEmpty() || e.id.toLowerCase(Locale.ROOT).contains(q)) shown.add(e);
            }
            adapter.notifyDataSetChanged();
            toggle.setText(showAll[0] ? R.string.imi_ver_only_main : R.string.imi_ver_show_all);
        };
        refresh.run();

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { refresh.run(); }
        });
        toggle.setOnClickListener(v -> { showAll[0] = !showAll[0]; refresh.run(); });

        AlertDialog dialog = new AlertDialog.Builder(context).setView(root).create();
        dialog.show();
        if (dialog.getWindow() != null)
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        listView.setOnItemClickListener((parent, v, pos, id) -> {
            Entry e = shown.get(pos);
            listener.onVersionSelected(e.id, e.snapshot);
            dialog.dismiss();
        });
    }

    /** true when the release id is >= 1.20.4 (or has a non 1.x scheme such as 26.1) */
    static boolean isSupported(String id) {
        String[] parts = id.split("[^0-9]+");
        int[] nums = new int[3];
        int n = 0;
        for (String p : parts) {
            if (p.isEmpty()) continue;
            if (n >= 3) break;
            try { nums[n++] = Integer.parseInt(p); } catch (NumberFormatException e) { return false; }
        }
        if (n == 0) return false;
        for (int i = 0; i < 3; i++) {
            if (nums[i] != MIN_VERSION[i]) return nums[i] > MIN_VERSION[i];
        }
        return true;
    }
}
