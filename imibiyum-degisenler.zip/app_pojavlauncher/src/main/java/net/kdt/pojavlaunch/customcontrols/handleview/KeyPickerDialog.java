package net.kdt.pojavlaunch.customcontrols.handleview;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import net.kdt.pojavlaunch.EfficientAndroidLWJGLKeycode;
import net.kdt.pojavlaunch.LwjglGlfwKeycode;
import net.kdt.pojavlaunch.R;
import net.kdt.pojavlaunch.customcontrols.ControlData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/**
 * A full on-screen keyboard used to pick the key(s) of a control button.
 * Up to 4 keys can be combined (for example SHIFT + W).
 */
public class KeyPickerDialog {
    public interface Listener {
        /**
         * @param keycodes always 4 entries, unused ones are GLFW_KEY_UNKNOWN
         * @param label    a short human readable name, for example "SHIFT+W"
         */
        void onPicked(int[] keycodes, String label);
    }

    private static final int GAP = Integer.MIN_VALUE; // spacer between key groups
    private static final int MAX_KEYS = 4;

    private static final class Key {
        final String label;
        final int code;
        final float weight;

        Key(String label, int code, float weight) {
            this.label = label;
            this.code = code;
            this.weight = weight;
        }
    }

    private final Context mContext;
    private final Listener mListener;
    private final LinkedHashSet<Integer> mSelected = new LinkedHashSet<>();
    private final Map<Integer, Button> mButtons = new HashMap<>();
    private final Map<Integer, String> mLabels = new HashMap<>();
    private TextView mSelectedText;
    private AlertDialog mDialog;

    public static void show(Context context, int[] initialKeycodes, Listener listener) {
        new KeyPickerDialog(context, initialKeycodes, listener).show();
    }

    private KeyPickerDialog(Context context, int[] initialKeycodes, Listener listener) {
        mContext = context;
        mListener = listener;
        List<List<Key>> rows = buildRows();
        for (List<Key> row : rows) {
            for (Key key : row) if (key.code != GAP) mLabels.put(key.code, key.label);
        }
        if (initialKeycodes != null) {
            for (int code : initialKeycodes) {
                if (code != LwjglGlfwKeycode.GLFW_KEY_UNKNOWN && mLabels.containsKey(code)
                        && mSelected.size() < MAX_KEYS) mSelected.add(code);
            }
        }
        buildDialog(rows);
    }

    private void show() {
        mDialog.show();
        if (mDialog.getWindow() != null) {
            mDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
        refresh();
    }

    // ---------- Layout data ----------

    private static Key k(String label, int code) { return new Key(label, code, 1f); }
    private static Key k(String label, int code, float weight) { return new Key(label, code, weight); }
    private static Key gap(float weight) { return new Key("", GAP, weight); }

    private static List<List<Key>> buildRows() {
        List<List<Key>> rows = new ArrayList<>();

        List<Key> r = new ArrayList<>();
        r.add(k("ESC", LwjglGlfwKeycode.GLFW_KEY_ESCAPE));
        r.add(gap(0.5f));
        for (int i = 0; i < 12; i++) r.add(k("F" + (i + 1), LwjglGlfwKeycode.GLFW_KEY_F1 + i));
        rows.add(r);

        r = new ArrayList<>();
        r.add(k("`", LwjglGlfwKeycode.GLFW_KEY_GRAVE_ACCENT));
        for (int i = 1; i <= 9; i++) r.add(k(String.valueOf(i), LwjglGlfwKeycode.GLFW_KEY_0 + i));
        r.add(k("0", LwjglGlfwKeycode.GLFW_KEY_0));
        r.add(k("-", LwjglGlfwKeycode.GLFW_KEY_MINUS));
        r.add(k("=", LwjglGlfwKeycode.GLFW_KEY_EQUAL));
        r.add(k("⌫", LwjglGlfwKeycode.GLFW_KEY_BACKSPACE, 1.6f));
        rows.add(r);

        r = new ArrayList<>();
        r.add(k("TAB", LwjglGlfwKeycode.GLFW_KEY_TAB, 1.5f));
        r.addAll(letters("QWERTYUIOP"));
        r.add(k("[", LwjglGlfwKeycode.GLFW_KEY_LEFT_BRACKET));
        r.add(k("]", LwjglGlfwKeycode.GLFW_KEY_RIGHT_BRACKET));
        r.add(k("\\", LwjglGlfwKeycode.GLFW_KEY_BACKSLASH, 1.1f));
        rows.add(r);

        r = new ArrayList<>();
        r.add(k("CAPS", LwjglGlfwKeycode.GLFW_KEY_CAPS_LOCK, 1.8f));
        r.addAll(letters("ASDFGHJKL"));
        r.add(k(";", LwjglGlfwKeycode.GLFW_KEY_SEMICOLON));
        r.add(k("'", LwjglGlfwKeycode.GLFW_KEY_APOSTROPHE));
        r.add(k("ENTER", LwjglGlfwKeycode.GLFW_KEY_ENTER, 2f));
        rows.add(r);

        r = new ArrayList<>();
        r.add(k("SHIFT", LwjglGlfwKeycode.GLFW_KEY_LEFT_SHIFT, 2.3f));
        r.addAll(letters("ZXCVBNM"));
        r.add(k(",", LwjglGlfwKeycode.GLFW_KEY_COMMA));
        r.add(k(".", LwjglGlfwKeycode.GLFW_KEY_PERIOD));
        r.add(k("/", LwjglGlfwKeycode.GLFW_KEY_SLASH));
        r.add(k("SHIFT", LwjglGlfwKeycode.GLFW_KEY_RIGHT_SHIFT, 2.3f));
        rows.add(r);

        r = new ArrayList<>();
        r.add(k("CTRL", LwjglGlfwKeycode.GLFW_KEY_LEFT_CONTROL, 1.5f));
        r.add(k("ALT", LwjglGlfwKeycode.GLFW_KEY_LEFT_ALT, 1.5f));
        r.add(k("BOŞLUK", LwjglGlfwKeycode.GLFW_KEY_SPACE, 6f));
        r.add(k("ALT", LwjglGlfwKeycode.GLFW_KEY_RIGHT_ALT, 1.5f));
        r.add(k("CTRL", LwjglGlfwKeycode.GLFW_KEY_RIGHT_CONTROL, 1.5f));
        rows.add(r);

        // Navigation block
        r = new ArrayList<>();
        r.add(k("INS", LwjglGlfwKeycode.GLFW_KEY_INSERT));
        r.add(k("HOME", LwjglGlfwKeycode.GLFW_KEY_HOME));
        r.add(k("PGUP", LwjglGlfwKeycode.GLFW_KEY_PAGE_UP));
        r.add(k("DEL", LwjglGlfwKeycode.GLFW_KEY_DELETE));
        r.add(k("END", LwjglGlfwKeycode.GLFW_KEY_END));
        r.add(k("PGDN", LwjglGlfwKeycode.GLFW_KEY_PAGE_DOWN));
        r.add(gap(0.5f));
        r.add(k("◀", LwjglGlfwKeycode.GLFW_KEY_LEFT));
        r.add(k("▲", LwjglGlfwKeycode.GLFW_KEY_UP));
        r.add(k("▼", LwjglGlfwKeycode.GLFW_KEY_DOWN));
        r.add(k("▶", LwjglGlfwKeycode.GLFW_KEY_RIGHT));
        rows.add(r);

        // Numpad
        r = new ArrayList<>();
        r.add(k("NUM", LwjglGlfwKeycode.GLFW_KEY_NUM_LOCK));
        r.add(k("KP/", LwjglGlfwKeycode.GLFW_KEY_KP_DIVIDE));
        r.add(k("KP*", LwjglGlfwKeycode.GLFW_KEY_KP_MULTIPLY));
        r.add(k("KP-", LwjglGlfwKeycode.GLFW_KEY_KP_SUBTRACT));
        r.add(k("KP+", LwjglGlfwKeycode.GLFW_KEY_KP_ADD));
        r.add(k("KP.", LwjglGlfwKeycode.GLFW_KEY_KP_DECIMAL));
        r.add(k("KP⏎", LwjglGlfwKeycode.GLFW_KEY_KP_ENTER));
        rows.add(r);

        r = new ArrayList<>();
        for (int i = 0; i <= 9; i++) r.add(k("KP" + i, LwjglGlfwKeycode.GLFW_KEY_KP_0 + i));
        rows.add(r);

        // Mouse and launcher specials
        r = new ArrayList<>();
        r.add(k("SOL TİK", ControlData.SPECIALBTN_MOUSEPRI, 1.4f));
        r.add(k("SAĞ TİK", ControlData.SPECIALBTN_MOUSESEC, 1.4f));
        r.add(k("ORTA TİK", ControlData.SPECIALBTN_MOUSEMID, 1.4f));
        r.add(k("TEKER ▲", ControlData.SPECIALBTN_SCROLLUP, 1.4f));
        r.add(k("TEKER ▼", ControlData.SPECIALBTN_SCROLLDOWN, 1.4f));
        rows.add(r);

        r = new ArrayList<>();
        r.add(k("KLAVYE", ControlData.SPECIALBTN_KEYBOARD, 1.4f));
        r.add(k("KONTROL A/K", ControlData.SPECIALBTN_TOGGLECTRL, 1.4f));
        r.add(k("SANAL FARE", ControlData.SPECIALBTN_VIRTUALMOUSE, 1.4f));
        r.add(k("MENÜ", ControlData.SPECIALBTN_MENU, 1.4f));
        rows.add(r);

        return rows;
    }

    private static List<Key> letters(String letters) {
        List<Key> list = new ArrayList<>();
        for (int i = 0; i < letters.length(); i++) {
            char c = letters.charAt(i);
            list.add(k(String.valueOf(c), LwjglGlfwKeycode.GLFW_KEY_A + (c - 'A')));
        }
        return list;
    }

    /** Short readable name of a set of keycodes, for example "SHIFT+W". Empty keycodes are skipped. */
    public static String describe(int[] codes) {
        Map<Integer, String> names = new HashMap<>();
        for (List<Key> row : buildRows()) {
            for (Key key : row) if (key.code != GAP) names.put(key.code, key.label);
        }
        StringBuilder sb = new StringBuilder();
        if (codes != null) {
            for (int code : codes) {
                if (code == LwjglGlfwKeycode.GLFW_KEY_UNKNOWN) continue;
                String label = names.get(code);
                if (sb.length() > 0) sb.append('+');
                sb.append(label == null ? "?" : label);
            }
        }
        return sb.toString();
    }

    /** Special launcher buttons are always valid, real keys must exist in the keycode table. */
    private static boolean isSupported(int code) {
        if (code < 0) return true;
        return EfficientAndroidLWJGLKeycode.getIndexByValue(code) != 0;
    }

    // ---------- Views ----------

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, mContext.getResources().getDisplayMetrics());
    }

    private GradientDrawable box(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(6));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private void buildDialog(List<List<Key>> rows) {
        int bg = mContext.getResources().getColor(R.color.background_app);
        int accent = mContext.getResources().getColor(R.color.imi_accent);

        LinearLayout root = new LinearLayout(mContext);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(dp(10), dp(8), dp(10), dp(8));

        TextView title = new TextView(mContext);
        title.setText(R.string.key_picker_title);
        title.setTextColor(Color.WHITE);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        root.addView(title);

        mSelectedText = new TextView(mContext);
        mSelectedText.setTextColor(accent);
        mSelectedText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        mSelectedText.setPadding(0, dp(2), 0, dp(6));
        root.addView(mSelectedText);

        // Category tabs keep the keyboard small enough for a phone in landscape
        final String[] tabNames = {"Ana tuşlar", "F / Yön", "Sayı bloğu", "Fare"};
        final int[] pageOfRow = {1, 0, 0, 0, 0, 0, 1, 2, 2, 3, 3};
        final int card = mContext.getResources().getColor(R.color.imi_card);
        final int stroke = mContext.getResources().getColor(R.color.imi_card_stroke);

        LinearLayout tabBar = new LinearLayout(mContext);
        tabBar.setOrientation(LinearLayout.HORIZONTAL);
        tabBar.setPadding(0, 0, 0, dp(4));
        root.addView(tabBar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView scroll = new ScrollView(mContext);
        LinearLayout keyboard = new LinearLayout(mContext);
        keyboard.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(keyboard);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        final LinearLayout[] pages = new LinearLayout[tabNames.length];
        final Button[] tabButtons = new Button[tabNames.length];
        final Runnable[] showPage = new Runnable[1];
        final int[] currentPage = {0};
        for (int pi = 0; pi < tabNames.length; pi++) {
            pages[pi] = new LinearLayout(mContext);
            pages[pi].setOrientation(LinearLayout.VERTICAL);
            keyboard.addView(pages[pi], new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            Button tab = new Button(mContext);
            tab.setText(tabNames[pi]);
            tab.setAllCaps(false);
            tab.setMinHeight(0);
            tab.setMinimumHeight(0);
            tab.setStateListAnimator(null);
            tab.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, dp(34), 1f);
            tp.setMargins(dp(2), 0, dp(2), 0);
            final int pageIndex = pi;
            tab.setOnClickListener(v -> { currentPage[0] = pageIndex; showPage[0].run(); });
            tabBar.addView(tab, tp);
            tabButtons[pi] = tab;
        }
        showPage[0] = () -> {
            for (int pi = 0; pi < pages.length; pi++) {
                boolean on = pi == currentPage[0];
                pages[pi].setVisibility(on ? View.VISIBLE : View.GONE);
                tabButtons[pi].setBackground(box(on ? accent : card, on ? 0 : stroke));
                tabButtons[pi].setTextColor(on ? Color.parseColor("#14161C") : Color.WHITE);
            }
        };
        showPage[0].run();

        for (int ri = 0; ri < rows.size(); ri++) {
            List<Key> row = rows.get(ri);
            LinearLayout rowLayout = new LinearLayout(mContext);
            rowLayout.setOrientation(LinearLayout.HORIZONTAL);
            rowLayout.setWeightSum(rowWeight(row));
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38));
            rowParams.setMargins(0, dp(2), 0, dp(2));
            pages[pageOfRow[ri]].addView(rowLayout, rowParams);

            for (Key key : row) {
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, key.weight);
                if (key.code == GAP) {
                    rowLayout.addView(new View(mContext), p);
                    continue;
                }
                p.setMargins(dp(2), 0, dp(2), 0);
                Button b = new Button(mContext);
                b.setText(key.label);
                b.setAllCaps(false);
                b.setSingleLine(true);
                b.setPadding(0, 0, 0, 0);
                b.setMinWidth(0);
                b.setMinHeight(0);
                b.setMinimumWidth(0);
                b.setMinimumHeight(0);
                b.setGravity(Gravity.CENTER);
                b.setTextSize(TypedValue.COMPLEX_UNIT_SP, key.label.length() > 4 ? 9 : 12);
                b.setStateListAnimator(null);
                final int code = key.code;
                if (isSupported(code)) {
                    b.setOnClickListener(v -> toggle(code));
                } else {
                    b.setEnabled(false);
                }
                mButtons.put(code, b);
                rowLayout.addView(b, p);
            }
        }

        LinearLayout footer = new LinearLayout(mContext);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        footer.setGravity(Gravity.END);
        footer.setPadding(0, dp(6), 0, 0);

        Button clear = footerButton(R.string.key_picker_clear, false);
        clear.setOnClickListener(v -> { mSelected.clear(); refresh(); });
        Button cancel = footerButton(R.string.key_picker_cancel, false);
        cancel.setOnClickListener(v -> mDialog.dismiss());
        Button ok = footerButton(R.string.key_picker_ok, true);
        ok.setOnClickListener(v -> confirm());

        footer.addView(clear);
        footer.addView(cancel);
        footer.addView(ok);
        root.addView(footer);

        mDialog = new AlertDialog.Builder(mContext).setView(root).create();
    }

    private Button footerButton(int textRes, boolean primary) {
        Button b = new Button(mContext);
        b.setText(textRes);
        b.setAllCaps(false);
        b.setTextColor(primary ? Color.parseColor("#14161C") : Color.WHITE);
        b.setBackground(box(primary ? mContext.getResources().getColor(R.color.imi_accent)
                : mContext.getResources().getColor(R.color.imi_card), primary ? 0 : mContext.getResources().getColor(R.color.imi_card_stroke)));
        b.setStateListAnimator(null);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40));
        p.setMargins(dp(6), 0, 0, 0);
        b.setLayoutParams(p);
        b.setPadding(dp(16), 0, dp(16), 0);
        return b;
    }

    private float rowWeight(List<Key> row) {
        float sum = 0;
        for (Key key : row) sum += key.weight;
        return sum;
    }

    // ---------- Behaviour ----------

    private void toggle(int code) {
        if (mSelected.contains(code)) {
            mSelected.remove(code);
        } else if (mSelected.size() >= MAX_KEYS) {
            Toast.makeText(mContext, R.string.key_picker_max, Toast.LENGTH_SHORT).show();
            return;
        } else {
            mSelected.add(code);
        }
        refresh();
    }

    private void refresh() {
        int accent = mContext.getResources().getColor(R.color.imi_accent);
        int card = mContext.getResources().getColor(R.color.imi_card);
        int stroke = mContext.getResources().getColor(R.color.imi_card_stroke);
        for (Map.Entry<Integer, Button> e : mButtons.entrySet()) {
            Button b = e.getValue();
            boolean selected = mSelected.contains(e.getKey());
            boolean enabled = b.isEnabled();
            b.setBackground(box(selected ? accent : card, selected ? 0 : stroke));
            b.setTextColor(selected ? Color.parseColor("#14161C") : (enabled ? Color.WHITE : Color.parseColor("#55FFFFFF")));
        }
        mSelectedText.setText(mContext.getString(R.string.key_picker_selected,
                mSelected.isEmpty() ? mContext.getString(R.string.key_picker_none) : buildLabel()));
    }

    private String buildLabel() {
        StringBuilder sb = new StringBuilder();
        for (int code : mSelected) {
            if (sb.length() > 0) sb.append('+');
            String label = mLabels.get(code);
            sb.append(label == null ? "?" : label);
        }
        return sb.toString();
    }

    private void confirm() {
        int[] codes = new int[MAX_KEYS];
        for (int i = 0; i < codes.length; i++) codes[i] = LwjglGlfwKeycode.GLFW_KEY_UNKNOWN;
        int i = 0;
        for (int code : mSelected) codes[i++] = code;
        mDialog.dismiss();
        if (mSelected.isEmpty()) return;
        mListener.onPicked(codes, buildLabel());
    }
}
